//
//  SongCollectionCell.swift
//  Jukebox
//
//  Created by Joseph Clements on 3/29/18.
//  Copyright © 2018 Joseph Clements. All rights reserved.
//

import UIKit

class SongCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var SongTitle: UILabel!
}
