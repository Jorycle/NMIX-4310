//
//  HubCollectionViewCell.swift
//  MidtermProject
//
//  Created by Jorycle on 3/19/18.
//  Copyright © 2018 Joseph Clements. All rights reserved.
//

import UIKit

class HubCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var CellLabel: UILabel!
    @IBOutlet weak var starImage: UIImageView!
    
}
