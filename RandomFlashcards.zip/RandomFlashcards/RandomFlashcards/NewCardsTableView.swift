//
//  NewCardsTableView.swift
//  MidtermProject
//
//  Created by Jorycle on 3/12/18.
//  Copyright © 2018 Joseph Clements. All rights reserved.
//

import UIKit

class NewCardsTableView: UITableView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
